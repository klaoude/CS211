#include "fat.h"

void printHello();

void afficher_Objet();

void printFAT(int n);

void printVolume(int s, int e);

int Run();